// Henry 

let quantidade = 1;
    const spanQuantidade = document.getElementById("quantidade");

    function alterarQuantidade(valor) {
      quantidade = Math.max(1, quantidade + valor);
      spanQuantidade.textContent = quantidade;
    }

// test - Felipe 

// Exemplo de tela de cadastro de produto com exibição na tela inicial e demais telas com melhorias

let produtos = JSON.parse(localStorage.getItem('produtos')) || [];

function renderProdutos() {
  const produtosContainer = document.getElementById('produtos');
  produtosContainer.innerHTML = '';

  produtos.forEach(produto => {
    const produtoDiv = document.createElement('div');
    produtoDiv.classList.add('produto-item');

    produtoDiv.innerHTML = `
      <h3>${produto.nome}</h3>
      <p>Preço: R$ ${produto.preco}</p>
      <p>${produto.descricao}</p>
    `;

    produtosContainer.appendChild(produtoDiv);
  });
}

function validarProduto(nome, preco) {
  if (!nome || preco <= 0 || isNaN(preco)) {
    alert('Preencha corretamente o nome e preço!');
    return false;
  }
  return true;
}

function cadastrarProduto(event) {
  event.preventDefault();

  const nome = document.getElementById('nome').value.trim();
  const preco = parseFloat(document.getElementById('preco').value);
  const descricao = document.getElementById('descricao').value.trim();

  if (!validarProduto(nome, preco)) return;

  const novoProduto = { nome, preco, descricao };
  produtos.push(novoProduto);

  localStorage.setItem('produtos', JSON.stringify(produtos));

  renderProdutos();

  document.getElementById('formCadastro').reset();
  document.getElementById('nome').focus();

  exibirMensagem('Produto cadastrado com sucesso!');
}

function exibirMensagem(msg) {
  const mensagemDiv = document.getElementById('mensagem');
  mensagemDiv.innerText = msg;
  mensagemDiv.style.display = 'block';

  setTimeout(() => {
    mensagemDiv.style.display = 'none';
  }, 3000);
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('formCadastro').addEventListener('submit', cadastrarProduto);
  renderProdutos();
});

/* HTML Exemplo:

<form id="formCadastro">
  <input type="text" id="nome" placeholder="Nome do Produto" required />
  <input type="number" id="preco" placeholder="Preço" required />
  <textarea id="descricao" placeholder="Descrição"></textarea>
  <button type="submit">Cadastrar Produto</button>
</form>

<div id="mensagem" style="display:none; color:green; margin-top:10px;"></div>

<h2>Produtos</h2>
<div id="produtos"></div>
*/
